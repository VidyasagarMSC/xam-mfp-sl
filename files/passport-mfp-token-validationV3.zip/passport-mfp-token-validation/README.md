The Passport Strategy for IBM MobileFirst™ Platform Foundation Security
===
The module passport-mfp-token-validation provides IBM MobileFirst Platform passport strategy to validate the request authorization header that accesses the protected resource.

## Sample
    var express = require('express'),
    passport = require('passport-mfp-token-validation').Passport,
    mfpStrategy = require('passport-mfp-token-validation').Strategy,
	analyticsFilter = require('passport-mfp-token-validation').AnalyticsFilter;
    
    //the configuration ('config') is optional if you wish to report events to the WL Analytics Server.
    var config = {
    	url : 'http://localhost:10080/worklight-analytics-service/data',
    	username : 'admin',
    	password : 'admin'
    };
    
    var options = {
		analytics : {
			onpremise : config
		}
	};

    

    passport.use(new mfpStrategy({publicKeyServerUrl:'http://localhost:10080/WLProject', analytics : {onpremise: config}}));

    var app = express();
    app.use(passport.initialize());
    
    //Initialize node filter
	var filter = analyticsFilter.init(app, '/v1/apps/:appid/service', options);

    	app.get('/v1/apps/:appid/service', passport.authenticate('mobilefirst-strategy', {session: false }),
			function(req, res){
				
				//set headers then send report
				filter.setHeaders(req);
				filter.sendReport();
				
				res.send(200, req.securityContext);
			}
		);

	app.listen(3000);
  ```

### Start Sample
``` bash
$ npm install express
$ npm install passport
$ npm install passport-mfp-token-validation
```

## MFP Strategy
```javascript
passport.use(new mfpStrategy(options));
```

The `options` is optional, which contains:

* `publicKeyServerUrl` (Mandatory) Specifies the URL of the MobileFirst Server from which the public key will be retrieved to verify the tokens.
* `scope` Space-separated string to define the list of realm names that are required for accessing the resource. If no scope is specified, only the mandatory scope will be checked in the token.
* `cacheSize` The maximum number of tokens allowed. The default value is 500.
* `logger` Defines a logger instance. The default value is the IBM® default logger, which outputs log messages to the console.

Besides to define the option `publicKeyServerUrl` in mfpStrategy constructor. It can also be specified in options in passport.authenticate method. But no matter where it is specified in, this option is required. Otherwise, the 400 error will be thrown.

The `analytics.onpremise` is optional, which contains :

* `url` The url that specifies the location of the operational analytics server. For example, `http://localhost:10080/worklight-analytics-service/data`.
* `username` The username if credentials are required.
* `password` The password if credentials are required.



## Token Verification
The passport-mfp-token-validation module verifies the authorization header of the request. The authorization header consists of the following elements:
```
Bearer Access_token ID_token
```
where

* `Bearer`
    (Mandatory) Is the required string for the token type, as defined in the OAuth 2.0 specification.
* *Access_token*
    (Mandatory) Encapsulates all of the security checks that the client has passed in the authorization phase.
* *ID_token*
    (Optional) Contains information about the user and device identity of the client.

*Bearer* and *Access_token* are mandatory. *ID_token* is optional. The passport-mfp-token-validation module will verify the token with the public key that is retrieved from the authorization server. If the token is verified successfully, the securityContext and user objects will be attached to the request object.

## Analytics Log Filter 
The passport-mfp-token-validation module provides a method to log network requests from the protected resource providing information such as roundtrip time and resource url.

* `setHeaders`
	(Mandatory) Is required to set the headers for the network event retrieved from the `req` object.
* `sendReport`
    (Mandatory) Sends the network log to the analytics server
* `init` (Mandatory) To initialize the node filter module set the `express` object `relative url` of the protected resource and `options` to configure analytics server.

**Note:** Currently only works for onpremise and not on bluemix.




### securityContext
After a successful validation, a security context object is added to the current request. 

The `securityContext` object contains the following fields:
* **imf.sub**: The sub value of the ID token or the unique ID of the client if there is no ID token.
* **imf.user**: The user value that is extracted from the ID token. If there is no ID token, this field holds a blank object.
* **imf.device**: The device value that is extracted from the ID token. If there is no ID token, this field holds a blank object.
* **imf.application**: The application value that is extracted from the ID token. If there is no ID token, this field holds a blank object.

### user
The user object in the request is returned by the passport framework. Its value is the same as the value of `imf.user` in the `securityContext` object.

## More Information
* [IBM MobileFirst Foundation (cross-platform)](http://www.ibm.com/support/knowledgecenter/SSHS8R_7.0.0/com.ibm.worklight.dev.doc/dev/r_oauth_filter_onprem.html)

* [IBM MobileFirst Foundation for iOS (iOS only)](http://www.ibm.com/support/knowledgecenter/SSHSCD_7.0.0/com.ibm.worklight.dev.doc/dev/r_oauth_filter_onprem.html)

## License
This package contains sample code provided in source code form. The samples are licensed under the under the Apache License, Version 2.0 (the "License").  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 and may also view the license in the license.txt file within this package.  Also see the notices.txt file within this package for additional notices.
